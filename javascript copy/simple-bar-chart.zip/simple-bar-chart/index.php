<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8" />
  <title>amCharts V4 Example - simple-bar-chart</title>
  <link rel="stylesheet" href="index.css" />
</head>

<body>
  <div id="chartdiv"></div>
  <script src="../../../core.js"></script>
  <script src="../../../charts.js"></script>
  <script src="../../../themes/animated.js"></script>
  <script src="./index.js"></script>
</body>

</html>